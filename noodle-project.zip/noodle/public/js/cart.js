function renderCart() {
  const cart = cartData();
  const box = document.getElementById('cart');
  let count = 0;
  let total = 0;

  box.innerHTML = '';

  if (!cart.length) {
    box.innerHTML = '<div class="empty">ยังไม่มีรายการในตะกร้า ลองเลือกเมนูที่ชอบกันก่อนนะ</div>';
    document.getElementById('checkout').disabled = true;
    document.getElementById('count').textContent = '0 รายการ';
    document.getElementById('summaryCount').textContent = '0';
    document.getElementById('total').textContent = '0.00';
    return;
  }

  cart.forEach((item, index) => {
    const sum = Number(item.price) * Number(item.quantity);
    count += Number(item.quantity);
    total += sum;

    const row = document.createElement('div');
    const product = document.createElement('div');
    const image = document.createElement('img');

    row.className = 'cart-row';
    product.className = 'cart-product';
    image.src = imageSource(item.image);
    image.alt = item.name;
    attachImageFallback(image);
    product.appendChild(image);
    product.insertAdjacentHTML('beforeend', `
      <div><b>${item.name}</b><small>฿${Number(item.price).toFixed(2)} / ชาม</small></div>
    `);

    row.appendChild(product);
    row.insertAdjacentHTML('beforeend', `
      <div class="qty">
        <button class="decrease" type="button" aria-label="ลดจำนวน ${item.name}">−</button>
        <span>${item.quantity}</span>
        <button class="increase" type="button" aria-label="เพิ่มจำนวน ${item.name}">＋</button>
        <button class="remove-item" type="button" aria-label="ลบ ${item.name}">×</button>
      </div>
      <strong class="row-sum">฿${sum.toFixed(2)}</strong>
    `);

    row.querySelector('.decrease').addEventListener('click', () => changeQuantity(index, -1));
    row.querySelector('.increase').addEventListener('click', () => changeQuantity(index, 1));
    row.querySelector('.remove-item').addEventListener('click', () => {
      const updatedCart = cartData();
      updatedCart.splice(index, 1);
      saveCart(updatedCart);
      renderCart();
    });

    box.appendChild(row);
  });

  document.getElementById('count').textContent = `${count} รายการ`;
  document.getElementById('summaryCount').textContent = count;
  document.getElementById('total').textContent = total.toFixed(2);
  document.getElementById('checkout').disabled = false;
}

function changeQuantity(index, amount) {
  const cart = cartData();

  if (!cart[index]) {
    return;
  }

  cart[index].quantity += amount;

  if (cart[index].quantity <= 0) {
    cart.splice(index, 1);
  }

  saveCart(cart);
  renderCart();
}

document.getElementById('checkout').addEventListener('click', async () => {
  const cart = cartData();

  if (!cart.length) {
    return;
  }

  const totalPrice = cart.reduce((sum, item) => sum + Number(item.price) * Number(item.quantity), 0);
  const totalCount = cart.reduce((sum, item) => sum + Number(item.quantity), 0);
  const checkoutButton = document.getElementById('checkout');

  checkoutButton.disabled = true;

  try {
    await api('/api/orders', {
      method: 'POST',
      body: JSON.stringify({
        items: cart.map((item) => ({
          menuId: item._id,
          name: item.name,
          price: Number(item.price),
          quantity: Number(item.quantity)
        })),
        totalPrice,
        totalCount
      })
    });

    localStorage.removeItem('noodleCart');
    location.href = 'orders.html';
  } catch (error) {
    showToast(error.message);
  } finally {
    checkoutButton.disabled = false;
  }
});

(async () => {
  if (await requireLogin()) {
    renderCart();
  }
})();

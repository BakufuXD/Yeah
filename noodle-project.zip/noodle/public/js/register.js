document.getElementById('registerForm').addEventListener('submit', async (event) => {
  event.preventDefault();

  const message = document.getElementById('message');
  const submitButton = event.currentTarget.querySelector('button[type="submit"]');
  const name = document.getElementById('name').value.trim();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  submitButton.disabled = true;
  message.textContent = '';

  try {
    await api('/api/users/register', {
      method: 'POST',
      body: JSON.stringify({ name, username, password })
    });

    message.textContent = 'สมัครสมาชิกสำเร็จ กำลังไปหน้าเข้าสู่ระบบ';
    message.className = 'message success';

    setTimeout(() => {
      location.href = 'login.html';
    }, 800);
  } catch (error) {
    message.textContent = error.message;
    message.className = 'message error';
  } finally {
    submitButton.disabled = false;
  }
});

let allMenus = [];
let activeCategory = 'all';
let searchText = '';

function renderMenu() {
  const menu = document.getElementById('menu');
  const results = document.getElementById('menuResults');
  const message = document.getElementById('menuMessage');
  const normalizedSearch = searchText.trim().toLocaleLowerCase('th-TH');

  const filteredMenus = allMenus.filter((item) => {
    const categoryMatches = activeCategory === 'all' || item.cat === activeCategory;
    const textMatches = !normalizedSearch || `${item.name} ${item.description}`
      .toLocaleLowerCase('th-TH')
      .includes(normalizedSearch);

    return categoryMatches && textMatches;
  });

  menu.innerHTML = '';
  results.textContent = `${filteredMenus.length} เมนู`;
  message.hidden = filteredMenus.length > 0;

  filteredMenus.forEach((item, index) => {
    const card = document.createElement('article');
    const categoryLabel = item.cat === 'tom-yum' ? 'ต้มยำ / รสจัด' : 'น้ำซุปกลมกล่อม';
    const image = document.createElement('img');

    card.className = 'menu-card';
    card.innerHTML = `
      <div class="menu-image-wrap">
        <span class="menu-image-tag">${categoryLabel}</span>
      </div>
      <div class="card-body">
        <h3>${item.name}</h3>
        <p>${item.description || 'ปรุงสดใหม่ พร้อมเสิร์ฟร้อน ๆ ทุกชาม'}</p>
        <div class="card-foot">
          <div class="menu-price">฿${Number(item.price).toLocaleString('th-TH')} <small>/ ชาม</small></div>
          <button class="button button-primary add" type="button">＋ ใส่ตะกร้า</button>
        </div>
      </div>
    `;

    image.src = imageSource(item.image);
    image.alt = item.name;
    image.loading = index > 3 ? 'lazy' : 'eager';
    attachImageFallback(image);
    card.querySelector('.menu-image-wrap').prepend(image);

    card.querySelector('.add').addEventListener('click', () => {
      const cart = cartData();
      const found = cart.find((cartItem) => cartItem._id === item._id);

      if (found) {
        found.quantity += 1;
      } else {
        cart.push({
          _id: item._id,
          name: item.name,
          price: Number(item.price),
          quantity: 1,
          image: item.image
        });
      }

      saveCart(cart);
      showToast(`เพิ่ม ${item.name} ลงตะกร้าแล้ว`);
    });

    menu.appendChild(card);
  });
}

async function loadMenu() {
  const menu = document.getElementById('menu');

  try {
    allMenus = await api('/api/menu?cat=all');
    renderMenu();
  } catch (error) {
    menu.innerHTML = `<div class="empty-state">${error.message}</div>`;
    document.getElementById('menuResults').textContent = '';
  }
}

document.querySelectorAll('.filter').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach((item) => item.classList.remove('active'));
    button.classList.add('active');
    activeCategory = button.dataset.cat;
    renderMenu();
  });
});

document.getElementById('menuSearch').addEventListener('input', (event) => {
  searchText = event.target.value;
  renderMenu();
});

loadMenu();

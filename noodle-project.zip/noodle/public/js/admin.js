const statusText = {
  pending: 'รอรับออเดอร์',
  cooking: 'กำลังปรุง',
  ready: 'พร้อมรับ',
  completed: 'เสร็จสิ้น',
  cancelled: 'ยกเลิก'
};

async function loadAdmin() {
  const info = await requireLogin();

  if (!info) {
    return;
  }

  if (info.user.type !== 'admin') {
    showToast('หน้านี้สำหรับผู้ดูแลระบบเท่านั้น');
    setTimeout(() => {
      location.href = 'index.html';
    }, 900);
    return;
  }

  try {
    const [menus, orders] = await Promise.all([
      api('/api/menu'),
      api('/api/orders')
    ]);

    document.getElementById('menuStat').textContent = menus.length;
    document.getElementById('orderStat').textContent = orders.length;
    document.getElementById('pendingStat').textContent = orders.filter((order) => order.status === 'pending').length;

    renderAdminMenu(menus);
    renderAdminOrders(orders);
  } catch (error) {
    showToast(error.message);
  }
}

function renderAdminMenu(menus) {
  const menuBox = document.getElementById('adminMenu');
  menuBox.innerHTML = '';

  if (!menus.length) {
    menuBox.innerHTML = '<div class="empty">ยังไม่มีเมนูในระบบ</div>';
    return;
  }

  menus.forEach((menu) => {
    const row = document.createElement('article');
    const image = document.createElement('img');

    row.className = 'admin-row';
    image.src = imageSource(menu.image);
    image.alt = menu.name;
    image.loading = 'lazy';
    attachImageFallback(image);

    row.appendChild(image);
    row.insertAdjacentHTML('beforeend', `
      <div>
        <b>${menu.name}</b>
        <small>฿${Number(menu.price).toFixed(2)} · ${menu.cat === 'tom-yum' ? 'ต้มยำและรสจัด' : 'น้ำซุปกลมกล่อม'}</small>
        <small>${menu.description || 'ไม่มีรายละเอียด'}</small>
      </div>
      <div class="admin-row-actions">
        <button class="edit" type="button">แก้ไข</button>
        <button class="danger del" type="button">ลบ</button>
      </div>
    `);

    row.querySelector('.edit').addEventListener('click', async () => {
      const name = prompt('ชื่อเมนู', menu.name);
      const price = prompt('ราคา (บาท)', menu.price);
      const description = prompt('รายละเอียดเมนู', menu.description || '');

      if (name === null || price === null || description === null) {
        return;
      }

      const nextPrice = Number(price);

      if (!name.trim() || !Number.isFinite(nextPrice) || nextPrice < 1) {
        showToast('กรุณาตรวจสอบชื่อเมนูและราคา');
        return;
      }

      try {
        await api(`/api/menu/${menu._id}`, {
          method: 'PATCH',
          body: JSON.stringify({
            name: name.trim(),
            price: nextPrice,
            description: description.trim()
          })
        });

        showToast('บันทึกการแก้ไขเมนูแล้ว');
        loadAdmin();
      } catch (error) {
        showToast(error.message);
      }
    });

    row.querySelector('.del').addEventListener('click', async () => {
      if (!confirm(`ยืนยันลบเมนู “${menu.name}” หรือไม่?`)) {
        return;
      }

      try {
        await api(`/api/menu/${menu._id}`, { method: 'DELETE' });
        showToast('ลบเมนูแล้ว');
        loadAdmin();
      } catch (error) {
        showToast(error.message);
      }
    });

    menuBox.appendChild(row);
  });
}

function renderAdminOrders(orders) {
  const orderBox = document.getElementById('adminOrders');
  orderBox.innerHTML = '';

  if (!orders.length) {
    orderBox.innerHTML = '<div class="empty">ยังไม่มีคำสั่งซื้อ</div>';
    return;
  }

  orders.slice(0, 8).forEach((order) => {
    const row = document.createElement('article');
    const date = new Date(order.createdAt).toLocaleString('th-TH', {
      dateStyle: 'short',
      timeStyle: 'short'
    });

    row.className = 'admin-order';
    row.innerHTML = `
      <div class="admin-order-top">
        <strong>#${order._id.slice(-8).toUpperCase()} · ${order.username}</strong>
        <strong>฿${Number(order.totalPrice).toFixed(2)}</strong>
      </div>
      <p>${date} · ${order.totalCount} ชาม</p>
      <div class="admin-order-bottom">
        <span class="status ${order.status}">${statusText[order.status]}</span>
        <select aria-label="เปลี่ยนสถานะคำสั่งซื้อ">
          ${Object.entries(statusText).map(([value, label]) => `<option value="${value}">${label}</option>`).join('')}
        </select>
      </div>
    `;

    const select = row.querySelector('select');
    select.value = order.status;

    select.addEventListener('change', async () => {
      try {
        await api(`/api/orders/${order._id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: select.value })
        });
        showToast('อัปเดตสถานะคำสั่งซื้อแล้ว');
        loadAdmin();
      } catch (error) {
        showToast(error.message);
      }
    });

    orderBox.appendChild(row);
  });
}

document.getElementById('addMenu').addEventListener('submit', async (event) => {
  event.preventDefault();

  const name = document.getElementById('name').value.trim();
  const price = Number(document.getElementById('price').value);
  const cat = document.getElementById('cat').value;
  const description = document.getElementById('description').value.trim();
  const image = document.getElementById('image').value;

  if (!name || !Number.isFinite(price) || price < 1) {
    showToast('กรุณากรอกชื่อเมนูและราคาที่ถูกต้อง');
    return;
  }

  try {
    await api('/api/menu', {
      method: 'POST',
      body: JSON.stringify({ name, price, cat, description, image })
    });

    event.target.reset();
    showToast('เพิ่มเมนูใหม่แล้ว');
    loadAdmin();
  } catch (error) {
    showToast(error.message);
  }
});

loadAdmin();

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.message || 'เกิดข้อผิดพลาด กรุณาลองอีกครั้ง');
  }

  return data;
}

function cartData() {
  try {
    return JSON.parse(localStorage.getItem('noodleCart') || '[]');
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem('noodleCart', JSON.stringify(cart));
  updateCartCount();
}

function updateCartCount() {
  const element = document.getElementById('cartCount');

  if (!element) {
    return;
  }

  const count = cartData().reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  element.textContent = count;
}

function imageSource(image) {
  if (typeof image === 'string' && /^https?:\/\//i.test(image)) {
    return image;
  }

  const filename = image || 'noodle.svg';
  return `img/${filename.replace(/^\/+/, '')}`;
}

function attachImageFallback(imageElement) {
  imageElement.addEventListener('error', () => {
    if (!imageElement.dataset.fallbackApplied) {
      imageElement.dataset.fallbackApplied = 'true';
      imageElement.src = 'img/noodle.svg';
    }
  }, { once: true });
}

function showToast(message) {
  const toast = document.getElementById('toast');

  if (!toast) {
    return;
  }

  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timeout);
  showToast.timeout = setTimeout(() => toast.classList.remove('show'), 2600);
}

async function syncHeader() {
  const authActions = document.getElementById('authActions');
  const logoutButton = document.getElementById('logout');
  const welcome = document.getElementById('welcome');
  const adminLink = document.getElementById('adminLink');

  try {
    const data = await api('/api/users/info');
    const isLoggedIn = Boolean(data.isLoggedIn);

    if (authActions) {
      authActions.hidden = isLoggedIn;
    }

    if (logoutButton) {
      logoutButton.hidden = !isLoggedIn;
    }

    if (welcome) {
      welcome.textContent = isLoggedIn
        ? `สวัสดี ${data.user.name || data.user.username}`
        : '';
    }

    if (adminLink) {
      adminLink.hidden = !isLoggedIn || data.user.type !== 'admin';
    }

    return data;
  } catch {
    if (authActions) {
      authActions.hidden = false;
    }

    if (logoutButton) {
      logoutButton.hidden = true;
    }

    if (adminLink) {
      adminLink.hidden = true;
    }

    return { isLoggedIn: false, user: null };
  }
}

async function requireLogin() {
  const data = await syncHeader();

  if (!data.isLoggedIn) {
    location.href = 'login.html';
    return null;
  }

  return data;
}

document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();
  syncHeader();

  document.getElementById('logout')?.addEventListener('click', async () => {
    try {
      await api('/api/users/logout', { method: 'POST' });
    } finally {
      localStorage.removeItem('noodleCart');
      location.href = 'index.html';
    }
  });
});

const statusText = {
  pending: 'รอรับออเดอร์',
  cooking: 'กำลังปรุง',
  ready: 'พร้อมรับ',
  completed: 'เสร็จสิ้น',
  cancelled: 'ยกเลิก'
};

const progressSteps = [
  { status: 'pending', label: 'รับออเดอร์แล้ว', icon: '✓' },
  { status: 'cooking', label: 'กำลังปรุง', icon: '♨' },
  { status: 'ready', label: 'พร้อมรับ', icon: '▣' },
  { status: 'completed', label: 'เสร็จสิ้น', icon: '✓' }
];

function renderProgress(status) {
  if (status === 'cancelled') {
    return '<div class="cancelled-note">คำสั่งซื้อนี้ถูกยกเลิกแล้ว</div>';
  }

  const activeIndex = progressSteps.findIndex((step) => step.status === status);

  return `
    <div class="order-progress">
      ${progressSteps.map((step, index) => `
        <div class="progress-step ${index <= activeIndex ? 'done' : ''}">
          <span class="progress-dot">${step.icon}</span>
          <span>${step.label}</span>
        </div>
      `).join('')}
    </div>
  `;
}

async function loadOrders() {
  if (!(await requireLogin())) {
    return;
  }

  const box = document.getElementById('orders');

  try {
    const orders = await api('/api/orders/mine');

    if (!orders.length) {
      box.innerHTML = '<div class="empty">ยังไม่มีประวัติการสั่งซื้อของคุณ <br><a class="text-link" href="index.html#menuSection">เลือกเมนูแรกของคุณ →</a></div>';
      return;
    }

    box.innerHTML = '';

    orders.forEach((order) => {
      const element = document.createElement('article');
      const date = new Date(order.createdAt).toLocaleString('th-TH', {
        dateStyle: 'medium',
        timeStyle: 'short'
      });

      element.className = 'order-card';
      element.innerHTML = `
        <div class="order-head">
          <div><div class="order-id">คำสั่งซื้อ #${order._id.slice(-8).toUpperCase()}</div><div class="order-date">${date}</div></div>
          <span class="status ${order.status}">${statusText[order.status]}</span>
        </div>
        ${renderProgress(order.status)}
        <div class="order-items">
          ${order.items.map((item) => `
            <div class="order-item"><span>${item.name} × ${item.quantity}</span><strong>฿${(Number(item.price) * Number(item.quantity)).toFixed(2)}</strong></div>
          `).join('')}
        </div>
        <div class="order-total"><span>ยอดรวมทั้งสิ้น</span><strong>฿${Number(order.totalPrice).toFixed(2)}</strong></div>
      `;

      box.appendChild(element);
    });
  } catch (error) {
    box.innerHTML = `<div class="empty">${error.message}</div>`;
  }
}

loadOrders();

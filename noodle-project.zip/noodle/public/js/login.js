document.getElementById('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();

  const message = document.getElementById('message');
  const submitButton = event.currentTarget.querySelector('button[type="submit"]');
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  submitButton.disabled = true;
  message.textContent = '';

  try {
    await api('/api/users/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });

    location.href = 'index.html';
  } catch (error) {
    message.textContent = error.message;
    message.className = 'message error';
  } finally {
    submitButton.disabled = false;
  }
});

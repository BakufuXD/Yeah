# ระบบสั่งก๋วยเตี๋ยวออนไลน์

Web Application สำหรับ Project วิชา Internet Programming

## เทคโนโลยี

- HTML5, CSS3, JavaScript และ DOM
- Node.js และ Express.js
- MongoDB และ Mongoose
- Session สำหรับสถานะการเข้าสู่ระบบ
- REST API สำหรับเมนู ผู้ใช้ และคำสั่งซื้อ

## วิธีติดตั้งและเริ่มต้นใช้งาน

1. ติดตั้ง Node.js และ MongoDB Community Server
2. เปิดบริการ MongoDB ในเครื่อง
3. เปิด Terminal ในโฟลเดอร์ที่มีไฟล์ `package.json`
4. รัน `npm install`
5. รัน `npm run seed` เพื่อใส่เมนูเริ่มต้นและบัญชีทดสอบ
6. รัน `npm start`
7. เปิด `http://localhost:3000` ใน Chrome

สั่ง `npm run seed` เพียงเมื่อจำเป็นต้องสร้างข้อมูลตัวอย่างใหม่ เพราะคำสั่งนี้จะเขียนทับรายการเมนูตัวอย่างในฐานข้อมูล

## บัญชีทดสอบ

**Admin**

- Username: `admin`
- Password: `1234`

**User**

- Username: `student`
- Password: `1234`

## รูปภาพเมนู

ภาพอาหารเป็นภาพถ่ายจาก Pexels ที่เชื่อมต่อผ่าน URL จึงต้องเชื่อมต่ออินเทอร์เน็ตเพื่อแสดงภาพได้ครบ

- [Thai noodle soup — Ngân Dương](https://www.pexels.com/photo/street-food-27860371/)
- [Thai noodle soup with beef — Son Tung Tran](https://www.pexels.com/photo/food-in-white-ceramic-bowl-6454806/)
- [Beef noodle soup](https://www.pexels.com/photo/close-up-of-a-bowl-of-a-beef-noodle-soup-20824932/)
- [Pork noodle soup](https://www.pexels.com/photo/photo-of-chopsticks-on-ceramic-bowl-4048338/)

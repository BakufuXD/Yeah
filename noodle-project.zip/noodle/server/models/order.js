const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
      required: true
    },
    username: {
      type: String,
      required: true
    },
    items: [
      {
        menuId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'menus'
        },
        name: {
          type: String,
          required: true
        },
        price: {
          type: Number,
          required: true
        },
        quantity: {
          type: Number,
          required: true
        },
        note: {
          type: String,
          default: ''
        }
      }
    ],
    totalPrice: {
      type: Number,
      required: true
    },
    totalCount: {
      type: Number,
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'cooking', 'ready', 'completed', 'cancelled'],
      default: 'pending'
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model('orders', orderSchema);

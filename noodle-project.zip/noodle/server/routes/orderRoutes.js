const express = require('express');
const Order = require('../models/order');
const { requireLogin, requireAdmin } = require('./userRoutes');

const router = express.Router();

router.post('/', requireLogin, async (req, res) => {
  try {
    const { items, totalPrice, totalCount } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        message: 'ไม่มีรายการอาหาร'
      });
    }

    const order = await Order.create({
      userId: req.session.user.id,
      username: req.session.user.username,
      items,
      totalPrice,
      totalCount
    });

    res.status(201).json({
      message: 'สั่งซื้อสำเร็จ',
      order
    });
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
});

router.get('/mine', requireLogin, async (req, res) => {
  try {
    const orders = await Order.find({
      userId: req.session.user.id
    }).sort({ createdAt: -1 });

    res.json(orders);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
});

router.get('/', requireAdmin, async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
});

router.patch('/:id/status', requireAdmin, async (req, res) => {
  try {
    const allowed = [
      'pending',
      'cooking',
      'ready',
      'completed',
      'cancelled'
    ];

    if (!allowed.includes(req.body.status)) {
      return res.status(400).json({
        message: 'สถานะไม่ถูกต้อง'
      });
    }

    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status: req.body.status },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({
        message: 'ไม่พบคำสั่งซื้อ'
      });
    }

    res.json(order);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
});

module.exports = router;

const express = require('express');
const Users = require('../models/user');

const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { name, username, password } = req.body;

    if (!name || !username || !password) {
      return res.status(400).json({
        success: false,
        message: 'กรุณากรอกข้อมูลให้ครบ'
      });
    }

    const exists = await Users.findOne({ username });

    if (exists) {
      return res.status(409).json({
        success: false,
        message: 'ชื่อผู้ใช้นี้มีอยู่แล้ว'
      });
    }

    const user = await Users.create({
      name,
      username,
      password,
      type: 'user'
    });

    res.status(201).json({
      success: true,
      message: 'สมัครสมาชิกสำเร็จ',
      user: {
        username: user.username
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน'
      });
    }

    const user = await Users.findOne({ username });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'ไม่พบชื่อผู้ใช้ในระบบ'
      });
    }

    if (user.password !== password) {
      return res.status(401).json({
        success: false,
        message: 'รหัสผ่านไม่ถูกต้อง'
      });
    }

    req.session.user = {
      id: user._id.toString(),
      username: user.username,
      name: user.name,
      type: user.type
    };

    res.json({
      success: true,
      message: 'เข้าสู่ระบบสำเร็จ',
      user: req.session.user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

router.get('/info', (req, res) => {
  res.json({
    isLoggedIn: Boolean(req.session.user),
    user: req.session.user || null,
  });
});

router.post('/logout', (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      return res.status(500).json({
        success: false,
        message: 'ออกจากระบบไม่สำเร็จ'
      });
    }

    res.clearCookie('connect.sid', { path: '/' });

    res.json({
      success: true,
      message: 'ออกจากระบบแล้ว'
    });
  });
});

function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({
      success: false,
      message: 'กรุณาเข้าสู่ระบบก่อน'
    });
  }

  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({
      success: false,
      message: 'กรุณาเข้าสู่ระบบก่อน'
    });
  }

  if (req.session.user.type !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'เฉพาะ Admin เท่านั้น'
    });
  }

  next();
}

router.requireLogin = requireLogin;
router.requireAdmin = requireAdmin;

module.exports = router;

const express = require('express');
const Menus = require('../models/menu');
const { requireAdmin } = require('./userRoutes');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const filter = req.query.cat;
    const query = filter && filter !== 'all' ? { cat: filter } : {};
    const menus = await Menus.find(query).sort({ name: 1 });

    res.json(menus);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
});

router.post('/', requireAdmin, async (req, res) => {
  try {
    const menu = await Menus.create(req.body);
    res.status(201).json(menu);
  } catch (error) {
    res.status(400).json({
      message: error.message
    });
  }
});

router.patch('/:id', requireAdmin, async (req, res) => {
  try {
    const menu = await Menus.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    if (!menu) {
      return res.status(404).json({
        message: 'ไม่พบเมนู'
      });
    }

    res.json(menu);
  } catch (error) {
    res.status(400).json({
      message: error.message
    });
  }
});

router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    const menu = await Menus.findByIdAndDelete(req.params.id);

    if (!menu) {
      return res.status(404).json({
        message: 'ไม่พบเมนู'
      });
    }

    res.json({
      message: 'ลบเมนูสำเร็จ'
    });
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
});

module.exports = router;

const path = require('path');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const User = require('./models/user');
const Menu = require('./models/menu');

dotenv.config({ path: path.join(__dirname, '.env') });

const menus = [
  {
    name: 'ก๋วยเตี๋ยวน้ำใส',
    price: 45,
    cat: 'noodle',
    description: 'น้ำซุปใสหอมกลมกล่อม เส้นนุ่มและเครื่องแน่น',
    image: 'https://images.pexels.com/photos/27860371/pexels-photo-27860371.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'ก๋วยเตี๋ยวต้มยำ',
    price: 55,
    cat: 'tom-yum',
    description: 'ต้มยำรสจัด เปรี้ยวเผ็ดกำลังดี',
    image: 'https://images.pexels.com/photos/6454806/pexels-photo-6454806.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'ก๋วยเตี๋ยวเรือ',
    price: 50,
    cat: 'noodle',
    description: 'น้ำซุปเข้มข้นสไตล์ก๋วยเตี๋ยวเรือ',
    image: 'https://images.pexels.com/photos/20824932/pexels-photo-20824932.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'ก๋วยเตี๋ยวเย็นตาโฟ',
    price: 55,
    cat: 'tom-yum',
    description: 'น้ำซุปสีเข้มพร้อมเครื่องและผักสด',
    image: 'https://images.pexels.com/photos/8895732/pexels-photo-8895732.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'ก๋วยเตี๋ยวหมูตุ๋น',
    price: 60,
    cat: 'noodle',
    description: 'หมูตุ๋นนุ่มกับน้ำซุปหอมเข้มข้น',
    image: 'https://images.pexels.com/photos/1907229/pexels-photo-1907229.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'ก๋วยเตี๋ยวเนื้อตุ๋น',
    price: 65,
    cat: 'noodle',
    description: 'เนื้อตุ๋นเปื่อยนุ่มกับผักและน้ำซุปเข้มข้น',
    image: 'https://images.pexels.com/photos/20824932/pexels-photo-20824932.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'ก๋วยเตี๋ยวต้มแซ่บ',
    price: 60,
    cat: 'tom-yum',
    description: 'น้ำซุปรสแซ่บ เผ็ดเปรี้ยวหอมเครื่องสมุนไพร',
    image: 'https://images.pexels.com/photos/8883368/pexels-photo-8883368.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'บะหมี่หมูแดง',
    price: 55,
    cat: 'noodle',
    description: 'บะหมี่เส้นไข่พร้อมหมูและเครื่องเคียง',
    image: 'https://images.pexels.com/photos/4048338/pexels-photo-4048338.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'เกาเหลาหมู',
    price: 60,
    cat: 'noodle',
    description: 'เกาเหลาไม่ใส่เส้น พร้อมผักและหมู',
    image: 'https://images.pexels.com/photos/27860371/pexels-photo-27860371.jpeg?auto=compress&cs=tinysrgb&w=900'
  },
  {
    name: 'เกาเหลาเนื้อ',
    price: 70,
    cat: 'noodle',
    description: 'เกาเหลาเนื้อพร้อมลูกชิ้นและผักสด',
    image: 'https://images.pexels.com/photos/4223933/pexels-photo-4223933.jpeg?auto=compress&cs=tinysrgb&w=900'
  }
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);

    await Menu.deleteMany({});
    await Menu.insertMany(menus);

    await User.updateOne(
      { username: 'admin' },
      {
        $set: {
          name: 'ผู้ดูแลร้าน',
          username: 'admin',
          password: '1234',
          type: 'admin'
        }
      },
      { upsert: true }
    );

    await User.updateOne(
      { username: 'student' },
      {
        $set: {
          name: 'ลูกค้าทดสอบ',
          username: 'student',
          password: '1234',
          type: 'user'
        }
      },
      { upsert: true }
    );

    console.log('Seed complete');
    console.log('Admin: admin / 1234');
    console.log('User : student / 1234');
  } catch (error) {
    console.error('Seed error:', error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

seed();
